from django.urls import path
from .views import (
    UserSearchView, SendFriendRequestView, AcceptFriendRequestView, 
    RejectFriendRequestView, ListFriendsView, PendingFriendRequestsView
)

urlpatterns = [
    path('search/', UserSearchView.as_view(), name='user-search'),
    path('send-friend-request/', SendFriendRequestView.as_view(), name='send-friend-request'),
    path('accept-friend-request/', AcceptFriendRequestView.as_view(), name='accept-friend-request'),
    path('reject-friend-request/', RejectFriendRequestView.as_view(), name='reject-friend-request'),
    path('friends/', ListFriendsView.as_view(), name='list-friends'),
    path('pending-requests/', PendingFriendRequestsView.as_view(), name='pending-requests'),
]
