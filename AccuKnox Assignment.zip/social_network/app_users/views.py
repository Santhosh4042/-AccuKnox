from django.shortcuts import render
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .models import User, FriendRequest
from .serializers import UserSerializer, FriendRequestSerializer
from django.db.models import Q
from django.utils.timezone import now
from datetime import timedelta

class UserSearchView(generics.ListAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        keyword = self.request.query_params.get('q', '').lower()
        return User.objects.filter(
            Q(email__iexact=keyword) |
            Q(username__icontains=keyword)
        ).distinct()

class SendFriendRequestView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        from_user = request.user
        to_user_id = request.data.get('to_user_id')
        to_user = User.objects.get(id=to_user_id)

        recent_requests = FriendRequest.objects.filter(
            from_user=from_user,
            created_at__gte=now() - timedelta(minutes=1)
        )
        if recent_requests.count() >= 3:
            return Response({"error": "Cannot send more than 3 requests within a minute."},
                            status=status.HTTP_429_TOO_MANY_REQUESTS)

        friend_request, created = FriendRequest.objects.get_or_create(from_user=from_user, to_user=to_user)

        if created:
            return Response({"message": "Friend request sent."}, status=status.HTTP_201_CREATED)
        else:
            return Response({"message": "Friend request already exists."}, status=status.HTTP_200_OK)

class AcceptFriendRequestView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        friend_request_id = request.data.get('friend_request_id')
        friend_request = FriendRequest.objects.get(id=friend_request_id, to_user=request.user)

        if friend_request:
            friend_request.accepted = True
            friend_request.save()
            return Response({"message": "Friend request accepted."}, status=status.HTTP_200_OK)
        return Response({"error": "Friend request not found."}, status=status.HTTP_404_NOT_FOUND)

class RejectFriendRequestView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        friend_request_id = request.data.get('friend_request_id')
        friend_request = FriendRequest.objects.get(id=friend_request_id, to_user=request.user)

        if friend_request:
            friend_request.delete()
            return Response({"message": "Friend request rejected."}, status=status.HTTP_200_OK)
        return Response({"error": "Friend request not found."}, status=status.HTTP_404_NOT_FOUND)

class ListFriendsView(generics.ListAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return User.objects.filter(
            Q(sent_requests__to_user=self.request.user, sent_requests__accepted=True) |
            Q(received_requests__from_user=self.request.user, received_requests__accepted=True)
        ).distinct()

class PendingFriendRequestsView(generics.ListAPIView):
    serializer_class = FriendRequestSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return FriendRequest.objects.filter(to_user=self.request.user, accepted=False)

